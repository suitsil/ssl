import express from "express";
import cors from "cors";

const app = express();
const port = 4000;

app.use(cors({ origin: "http://localhost:3000" }));

const client = {};

const send = (id, text) => {
    if (client[id]) {
        client[id].write(`data: ${text}\n\n`);
    }
};

app.post("/order", (req, res) => {
    const id = Date.now().toString();
    setTimeout(() => send(id, "buyurtma qabul qilindi"), 4000);
    setTimeout(() => send(id, "tayyorlanmoqda"), 7000);
    setTimeout(() => send(id, "zakaz tayyor"), 10000);

    res.json(id);
});

app.get("/event/:id", (req, res) => {
    const id = req.params.id;

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("cache-control", "no-cache");
    res.setHeader("connection", "keep-alive");
    client[id] = res;
});

app.listen(port, () => {
    console.log(`Example app listening on port ${port}`);
});