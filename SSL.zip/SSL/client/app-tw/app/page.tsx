"use client";
import axios from "axios";
import { useState } from "react";


export default function Home() {
  const [messages, setMessages] = useState([
    "...."
  ]
  );

  const createOrderHandler = async () => {
    const order = "lavash va ichilgan kola";
    const res = await axios.post(" http://localhost:4000/order ", order);

    const es = new EventSource(`http://localhost:4000/event/${res.data}`);

    es.onmessage = (message) => {

      setMessages([message.data]);
    }
  };

  return (
    <>
      <button
        onClick={createOrderHandler}
        className="px-6 py-4 bg-amber-950 rounded-full hover:cursor-pointer"
      >
        zakaz berish
      </button>

      {messages.map((m) => (
        <p key={m}>{m}</p>
      ))}
    </>
  )
}



